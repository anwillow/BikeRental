﻿namespace BikeRentalApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            dataGridView1 = new DataGridView();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            dataGridView2 = new DataGridView();
            button7 = new Button();
            dataGridView3 = new DataGridView();
            dataGridView4 = new DataGridView();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView4).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(139, 185);
            button1.Name = "button1";
            button1.Size = new Size(208, 45);
            button1.TabIndex = 0;
            button1.Text = "Guest";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(469, 185);
            button2.Name = "button2";
            button2.Size = new Size(208, 45);
            button2.TabIndex = 1;
            button2.Text = "Admin";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(236, 0);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(344, 425);
            dataGridView1.TabIndex = 2;
            dataGridView1.Visible = false;
            // 
            // button3
            // 
            button3.Location = new Point(639, 371);
            button3.Name = "button3";
            button3.Size = new Size(149, 42);
            button3.TabIndex = 3;
            button3.Text = "Back";
            button3.UseVisualStyleBackColor = true;
            button3.Visible = false;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(78, 185);
            button4.Name = "button4";
            button4.Size = new Size(152, 45);
            button4.TabIndex = 4;
            button4.Text = "Bike DB";
            button4.UseVisualStyleBackColor = true;
            button4.Visible = false;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Location = new Point(297, 185);
            button5.Name = "button5";
            button5.Size = new Size(154, 45);
            button5.TabIndex = 5;
            button5.Text = "Trip DB";
            button5.UseVisualStyleBackColor = true;
            button5.Visible = false;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Location = new Point(523, 185);
            button6.Name = "button6";
            button6.Size = new Size(154, 45);
            button6.TabIndex = 6;
            button6.Text = "Account DB";
            button6.UseVisualStyleBackColor = true;
            button6.Visible = false;
            button6.Click += button6_Click;
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(12, 0);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.RowTemplate.Height = 25;
            dataGridView2.Size = new Size(776, 230);
            dataGridView2.TabIndex = 7;
            dataGridView2.Visible = false;
            // 
            // button7
            // 
            button7.Location = new Point(639, 371);
            button7.Name = "button7";
            button7.Size = new Size(149, 42);
            button7.TabIndex = 8;
            button7.Text = "Back";
            button7.UseVisualStyleBackColor = true;
            button7.Visible = false;
            button7.Click += button7_Click;
            // 
            // dataGridView3
            // 
            dataGridView3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView3.Location = new Point(12, 0);
            dataGridView3.Name = "dataGridView3";
            dataGridView3.RowTemplate.Height = 25;
            dataGridView3.Size = new Size(776, 230);
            dataGridView3.TabIndex = 9;
            dataGridView3.Visible = false;
            // 
            // dataGridView4
            // 
            dataGridView4.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView4.Location = new Point(12, 0);
            dataGridView4.Name = "dataGridView4";
            dataGridView4.RowTemplate.Height = 25;
            dataGridView4.Size = new Size(776, 230);
            dataGridView4.TabIndex = 10;
            dataGridView4.Visible = false;
            // 
            // button8
            // 
            button8.Location = new Point(639, 323);
            button8.Name = "button8";
            button8.Size = new Size(149, 42);
            button8.TabIndex = 11;
            button8.Text = "Save changes";
            button8.UseVisualStyleBackColor = true;
            button8.Visible = false;
            button8.Click += button8_Click;
            // 
            // button9
            // 
            button9.Location = new Point(639, 323);
            button9.Name = "button9";
            button9.Size = new Size(149, 42);
            button9.TabIndex = 12;
            button9.Text = "Save Changes";
            button9.UseVisualStyleBackColor = true;
            button9.Visible = false;
            button9.Click += button9_Click;
            // 
            // button10
            // 
            button10.Location = new Point(639, 323);
            button10.Name = "button10";
            button10.Size = new Size(149, 42);
            button10.TabIndex = 13;
            button10.Text = "Save Changes";
            button10.UseVisualStyleBackColor = true;
            button10.Visible = false;
            button10.Click += button10_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(dataGridView4);
            Controls.Add(dataGridView3);
            Controls.Add(button7);
            Controls.Add(dataGridView2);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(dataGridView1);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView4).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button button1;
        private Button button2;
        private DataGridView dataGridView1;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private DataGridView dataGridView2;
        private Button button7;
        private DataGridView dataGridView3;
        private DataGridView dataGridView4;
        private Button button8;
        private Button button9;
        private Button button10;
    }
}